# OUTBREAK: ÚLTIMO SOBREVIVENTE

Projeto 3D jogável em Godot 4.x, criado para servir como uma base expansível de survival horror em terceira pessoa.

## Como executar
1. Instale Godot 4.x.
2. Importe/abra a pasta `outbreak_ultimo_sobrevivente`.
3. Abra `project.godot`.
4. Pressione Play.

## Controles
- WASD: movimentação
- Shift: sprint
- Mouse esquerdo: ataque rápido
- F: ataque forte
- Espaço: esquiva
- Q: troca de arma
- I: inventário
- R: reiniciar após morte
- E: interação (base preparada)

## Sistemas incluídos
- Mundo 3D procedural com floresta, estrada, casas, rochas e veículos.
- Ciclo de dia/noite com alteração de iluminação, ambiente e neblina.
- Personagem em terceira pessoa com câmera, sprint, esquiva, vida, stamina, fome e sede.
- Katana com ataques rápidos/fortes e detecção de alcance + direção.
- Vários arquétipos de zumbi: comum, corredor, brutamontes e rastejante.
- IA com estados de patrulha/perseguição e movimento com desvio lateral.
- Hordas com maior frequência à noite.
- Partículas de impacto/morte.
- Inventário visual.
- Progressão base e HUD.
- Estrutura modular para adicionar armas, missões, loot, áudio, animações e assets.

## Nota sobre qualidade AAA
O projeto usa geração procedural e meshes nativas do Godot para ser auto-contido e imediatamente executável, sem depender de downloads de assets proprietários. Para chegar a um nível comercial/AAA, a próxima etapa é substituir os modelos procedurais por personagens, animações, materiais PBR, vegetação, efeitos sonoros e ambientes produzidos/importados por artistas, além de adicionar navegação por NavigationServer3D, sistema de armas de fogo, save/load, loot persistente e missões completas.
