extends CanvasLayer

var player
var hp_bar
var stamina_bar
var thirst_bar
var hunger_bar
var status
var mission
var inv_panel
var message
var message_timer=0.0

func _ready():
    player=get_tree().get_first_node_in_group("player")
    if not player: player=get_parent().get_node_or_null("Player")
    _build()

func _process(delta):
    if not is_instance_valid(player): return
    hp_bar.value=player.hp
    stamina_bar.value=player.stamina
    thirst_bar.value=player.thirst
    hunger_bar.value=player.hunger
    status.text="LV %d  |  %s  |  XP %d\nMunição: %d\nZumbis próximos: %d" % [player.level,player.weapons[player.weapon_index],player.xp, player.ammo.get(player.weapons[player.weapon_index],0),get_tree().get_nodes_in_group("zombies").size()]
    if message_timer>0:
        message_timer-=delta
        message.visible=true
    else: message.visible=false
    if Input.is_action_just_pressed("inventory"):
        inv_panel.visible=!inv_panel.visible

func show_message(t):
    message.text=t
    message_timer=4

func _build():
    var root=Control.new()
    root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
    add_child(root)
    hp_bar=_bar(Vector2(24,24),Color(0.8,0.1,0.08),"VIDA")
    stamina_bar=_bar(Vector2(24,54),Color(0.9,0.75,0.15),"STAMINA")
    thirst_bar=_bar(Vector2(24,84),Color(0.1,0.55,0.9),"SEDE")
    hunger_bar=_bar(Vector2(24,114),Color(0.55,0.35,0.1),"FOME")
    status=Label.new()
    status.position=Vector2(24,150)
    status.add_theme_font_size_override("font_size",18)
    root.add_child(status)
    mission=Label.new()
    mission.text="MISSÃO PRINCIPAL\nExplore a floresta e encontre a saída.\n\n[WASD] mover  [Shift] correr\n[Mouse] ataque  [F] golpe forte\n[Espaço] esquiva  [Q] arma  [E] interagir\n[I] inventário"
    mission.position=Vector2(900,24)
    mission.size=Vector2(350,220)
    mission.add_theme_font_size_override("font_size",16)
    root.add_child(mission)
    message=Label.new()
    message.position=Vector2(360,620)
    message.size=Vector2(560,60)
    message.horizontal_alignment=HORIZONTAL_ALIGNMENT_CENTER
    message.add_theme_font_size_override("font_size",24)
    root.add_child(message)
    inv_panel=Panel.new()
    inv_panel.position=Vector2(380,160)
    inv_panel.size=Vector2(520,390)
    inv_panel.visible=false
    root.add_child(inv_panel)
    var inv=Label.new()
    inv.position=Vector2(28,24)
    inv.text="INVENTÁRIO\n\n🥫 Comida ........ 7\n💧 Água .......... 5\n💊 Medicamentos .. 3\n🔩 Materiais ..... 12\n💵 Dinheiro ...... $84\n\nARMAS\n⚔ Katana          equipada\n🔫 Pistola         desbloqueável\n🔫 Espingarda      desbloqueável\n🔫 SMG             desbloqueável\n🔫 Rifle           desbloqueável\n\nI — fechar inventário"
    inv.add_theme_font_size_override("font_size",20)
    inv_panel.add_child(inv)

func _bar(pos,color,title):
    var b=ProgressBar.new()
    b.position=pos
    b.size=Vector2(280,22)
    b.max_value=100
    b.value=100
    b.show_percentage=false
    var bg=StyleBoxFlat.new()
    bg.bg_color=Color(0.02,0.025,0.03,0.75)
    bg.corner_radius_top_left=5; bg.corner_radius_top_right=5
    bg.corner_radius_bottom_left=5; bg.corner_radius_bottom_right=5
    b.add_theme_stylebox_override("background",bg)
    var fill=StyleBoxFlat.new()
    fill.bg_color=color
    fill.corner_radius_top_left=5; fill.corner_radius_top_right=5
    fill.corner_radius_bottom_left=5; fill.corner_radius_bottom_right=5
    b.add_theme_stylebox_override("fill",fill)
    add_child(b)
    var l=Label.new()
    l.text=title
    l.position=pos+Vector2(8,0)
    l.add_theme_color_override("font_color",Color.WHITE)
    add_child(l)
    return b
