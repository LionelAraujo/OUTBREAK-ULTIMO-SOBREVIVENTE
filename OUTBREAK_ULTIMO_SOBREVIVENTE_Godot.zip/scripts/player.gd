extends CharacterBody3D

var speed := 5.2
var sprint_speed := 9.0
var gravity := 22.0
var hp := 100.0
var max_hp := 100.0
var stamina := 100.0
var max_stamina := 100.0
var hunger := 100.0
var thirst := 100.0
var xp := 0
var level := 1
var dead := false
var attacking := false
var attack_timer := 0.0
var attack_cooldown := 0.0
var invincible := 0.0
var camera: Camera3D
var model: Node3D
var katana: MeshInstance3D
var inventory_open := false
var weapon_index := 0
var weapons := ["Katana","Pistola","Espingarda","SMG","Rifle"]
var ammo := {"Pistola":24,"Espingarda":8,"SMG":60,"Rifle":12}

func _ready():
    _build_body()
    _build_camera()

func _physics_process(delta):
    if dead:
        return
    attack_cooldown = max(0.0, attack_cooldown-delta)
    invincible = max(0.0, invincible-delta)
    hunger = max(0,hunger-delta*0.018)
    thirst = max(0,thirst-delta*0.028)
    _move(delta)
    _combat(delta)
    _animate(delta)
    if hp <= 0: _die()

func _move(delta):
    var input2 := Input.get_vector("move_left","move_right","move_forward","move_back")
    var dir := Vector3(input2.x,0,input2.y)
    var cam_basis = camera.global_transform.basis
    dir = (cam_basis * dir)
    dir.y = 0
    if dir.length() > 1: dir = dir.normalized()
    var sprinting = Input.is_action_pressed("sprint") and stamina > 5 and dir.length()>0
    var target = sprint_speed if sprinting else speed
    velocity.x = move_toward(velocity.x, dir.x*target, 30*delta)
    velocity.z = move_toward(velocity.z, dir.z*target, 30*delta)
    if sprinting: stamina = max(0,stamina-delta*20)
    else: stamina = min(max_stamina,stamina+delta*12)
    if dir.length()>0.1:
        model.look_at(global_position + Vector3(dir.x,0,dir.z), Vector3.UP)
    if not is_on_floor(): velocity.y -= gravity*delta
    else: velocity.y = 0
    if Input.is_action_just_pressed("dodge") and stamina >= 25:
        velocity = -global_transform.basis.z*12
        stamina -= 25
        invincible = 0.35
    move_and_slide()

func _combat(delta):
    if Input.is_action_just_pressed("attack") and attack_cooldown<=0:
        _attack(false)
    if Input.is_action_just_pressed("heavy_attack") and attack_cooldown<=0:
        _attack(true)
    if Input.is_action_just_pressed("switch_weapon"):
        weapon_index = (weapon_index+1)%weapons.size()
    if attack_timer>0:
        attack_timer -= delta
        katana.rotation.z = sin(attack_timer*20)*1.2

func _attack(heavy:bool):
    if weapon_index != 0:
        return
    attacking = true
    attack_timer = 0.28 if not heavy else 0.48
    attack_cooldown = 0.32 if not heavy else 0.65
    katana.rotation.z = -1.2 if not heavy else -1.7
    for z in get_tree().get_nodes_in_group("zombies"):
        if is_instance_valid(z):
            var dist = global_position.distance_to(z.global_position)
            var to = (z.global_position-global_position).normalized()
            var facing = -global_transform.basis.z.dot(to)
            if dist < (3.1 if not heavy else 3.8) and facing > 0.05:
                z.take_damage(32 if not heavy else 65)
    _flash_slash()

func _flash_slash():
    var p := GPUParticles3D.new()
    p.amount = 18
    p.lifetime = 0.22
    p.position = Vector3(0,1.2,-1.0)
    add_child(p)
    var pm := ParticleProcessMaterial.new()
    pm.direction = Vector3(0,0,-1)
    pm.spread = 70
    pm.initial_velocity_min = 4
    pm.initial_velocity_max = 9
    pm.gravity = Vector3(0,-2,0)
    p.process_material = pm
    var quad := QuadMesh.new()
    quad.size = Vector2(0.25,0.25)
    p.draw_pass_1 = quad
    p.emitting = true
    await get_tree().create_timer(0.3).timeout
    p.queue_free()

func take_damage(amount):
    if invincible>0 or dead: return
    hp -= amount
    if hp<=0: _die()

func heal(amount):
    hp = min(max_hp,hp+amount)

func _die():
    dead = true
    velocity = Vector3.ZERO
    model.rotation_degrees.x = -80

func _build_body():
    model = Node3D.new()
    add_child(model)
    var torso := MeshInstance3D.new()
    var bm := CapsuleMesh.new()
    bm.radius = 0.42
    bm.height = 1.5
    torso.mesh = bm
    torso.position.y = 1.0
    torso.material_override = _mat(Color(0.16,0.20,0.22),0.7)
    model.add_child(torso)
    var head := MeshInstance3D.new()
    var hm := SphereMesh.new()
    hm.radius = 0.32
    hm.height = 0.64
    head.mesh = hm
    head.position.y = 2.05
    head.material_override = _mat(Color(0.52,0.44,0.38),0.9)
    model.add_child(head)
    katana = MeshInstance3D.new()
    var blade := BoxMesh.new()
    blade.size = Vector3(0.08,1.7,0.12)
    katana.mesh = blade
    katana.position = Vector3(0.7,1.0,-0.3)
    katana.rotation_degrees.x = 90
    katana.material_override = _mat(Color(0.72,0.76,0.82),0.18)
    model.add_child(katana)

func _build_camera():
    camera = Camera3D.new()
    camera.position = Vector3(0,4.2,8.2)
    camera.rotation_degrees.x = -18
    camera.current = true
    add_child(camera)

func _animate(delta):
    if velocity.length()>0.5:
        var bob = sin(Time.get_ticks_msec()*0.012)*0.025
        model.position.y = bob

func _mat(c:Color,r:float)->StandardMaterial3D:
    var m=StandardMaterial3D.new()
    m.albedo_color=c
    m.roughness=r
    return m
