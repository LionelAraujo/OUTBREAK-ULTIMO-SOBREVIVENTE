extends Node3D

var player
var world
var ui
var day_clock := 0.18
var spawn_timer := 0.0
var boss_spawned := false
var zombies: Array[Node] = []
var rng := RandomNumberGenerator.new()

func _ready():
    rng.randomize()
    _build_environment()
    _build_world()
    _build_player()
    _build_ui()

func _process(delta):
    day_clock = fmod(day_clock + delta * 0.003, 1.0)
    _update_sky()
    spawn_timer -= delta
    if spawn_timer <= 0:
        _spawn_wave()
        spawn_timer = 7.0 if _is_night() else 12.0
    if player and player.dead:
        ui.show_message("VOCÊ MORREU — pressione R para reiniciar")
        if Input.is_key_pressed(KEY_R):
            get_tree().reload_current_scene()

func _is_night() -> bool:
    return day_clock < 0.23 or day_clock > 0.72

func _build_environment():
    world = WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color(0.025,0.035,0.05)
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color(0.28,0.32,0.40)
    env.ambient_light_energy = 0.55
    env.fog_enabled = true
    env.fog_light_color = Color(0.16,0.19,0.22)
    env.fog_light_energy = 0.5
    env.fog_density = 0.012
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    world.environment = env
    add_child(world)

    var sun := DirectionalLight3D.new()
    sun.name = "MoonSun"
    sun.rotation_degrees = Vector3(-48,-25,0)
    sun.light_energy = 1.0
    sun.shadow_enabled = true
    add_child(sun)

func _update_sky():
    var sun = get_node_or_null("MoonSun")
    if not sun: return
    var angle = day_clock * TAU
    sun.rotation_degrees.x = -35 + sin(angle) * 75
    sun.rotation_degrees.y = -25 + cos(angle) * 40
    var night := _is_night()
    sun.light_energy = 0.32 if night else 1.35
    world.environment.fog_density = 0.026 if night else 0.009
    world.environment.ambient_light_energy = 0.25 if night else 0.7
    world.environment.ambient_light_color = Color(0.18,0.21,0.30) if night else Color(0.55,0.58,0.62)

func _build_world():
    # Ground
    var ground := MeshInstance3D.new()
    var plane := PlaneMesh.new()
    plane.size = Vector2(220,220)
    ground.mesh = plane
    ground.material_override = _mat(Color(0.10,0.13,0.09), 1.0)
    add_child(ground)

    # Road
    var road := MeshInstance3D.new()
    var rmesh := BoxMesh.new()
    rmesh.size = Vector3(16,0.08,220)
    road.mesh = rmesh
    road.position.y = 0.04
    road.material_override = _mat(Color(0.16,0.13,0.10), 1.0)
    add_child(road)

    # Forest + POIs
    for i in range(190):
        var p = Vector3(rng.randf_range(-100,100),0,rng.randf_range(-100,100))
        if abs(p.x) < 11: continue
        _make_tree(p, rng.randf_range(0.8,1.5))

    for i in range(50):
        var p = Vector3(rng.randf_range(-100,100),0.35,rng.randf_range(-100,100))
        if abs(p.x) < 13: continue
        _make_rock(p, rng.randf_range(0.6,1.6))

    _make_house(Vector3(32,0,18), Vector3(11,6,10), "CASA ABANDONADA")
    _make_house(Vector3(-36,0,-30), Vector3(13,7,9), "ABRIGO")
    _make_house(Vector3(52,0,-45), Vector3(9,5,12), "POSTO FLORESTAL")
    _make_vehicle(Vector3(15,0,8), 0.25)
    _make_vehicle(Vector3(-20,0,-8), -0.6)
    _make_vehicle(Vector3(45,0,2), 1.2)

func _make_tree(p:Vector3, s:float):
    var root := Node3D.new()
    root.position = p
    add_child(root)
    var trunk := MeshInstance3D.new()
    var tm := CylinderMesh.new()
    tm.top_radius = 0.28*s
    tm.bottom_radius = 0.42*s
    tm.height = 4.0*s
    trunk.mesh = tm
    trunk.position.y = 2.0*s
    trunk.material_override = _mat(Color(0.12,0.075,0.045),1)
    root.add_child(trunk)
    for j in range(3):
        var crown := MeshInstance3D.new()
        var cm := SphereMesh.new()
        cm.radius = 2.1*s
        cm.height = 4.0*s
        crown.mesh = cm
        crown.position = Vector3(rng.randf_range(-0.8,0.8),4.2*s+j*0.5,rng.randf_range(-0.8,0.8))
        crown.scale = Vector3(1.15,0.8,1.15)
        crown.material_override = _mat(Color(0.035,0.10,0.045),0.95)
        root.add_child(crown)

func _make_rock(p:Vector3, s:float):
    var m := MeshInstance3D.new()
    var mesh := SphereMesh.new()
    mesh.radius = s
    mesh.height = s*1.2
    m.mesh = mesh
    m.scale = Vector3(1.5,0.7,1.0)
    m.position = p
    m.material_override = _mat(Color(0.20,0.21,0.19),1)
    add_child(m)

func _make_house(p:Vector3, size:Vector3, label:String):
    var root := Node3D.new()
    root.position = p
    root.name = label
    add_child(root)
    var body := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    body.mesh = bm
    body.position.y = size.y/2
    body.material_override = _mat(Color(0.22,0.19,0.17),1)
    root.add_child(body)
    var roof := MeshInstance3D.new()
    var rm := PrismMesh.new()
    rm.size = Vector3(size.x+1,2,size.z+1)
    roof.mesh = rm
    roof.position.y = size.y+1.2
    roof.rotation_degrees.z = 180
    roof.material_override = _mat(Color(0.08,0.075,0.07),1)
    root.add_child(roof)
    var light := OmniLight3D.new()
    light.position = Vector3(0,2,0)
    light.light_energy = 0.7
    light.omni_range = 8
    light.light_color = Color(1.0,0.55,0.28)
    root.add_child(light)

func _make_vehicle(p:Vector3, rot:float):
    var root := Node3D.new()
    root.position = p
    root.rotation.y = rot
    add_child(root)
    var body := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(2.3,0.9,4.4)
    body.mesh = bm
    body.position.y = 0.75
    body.material_override = _mat(Color(0.09,0.10,0.105),0.8)
    root.add_child(body)
    for x in [-1.0,1.0]:
        for z in [-1.45,1.45]:
            var wheel := MeshInstance3D.new()
            var wm := CylinderMesh.new()
            wm.top_radius = 0.38
            wm.bottom_radius = 0.38
            wm.height = 0.25
            wheel.mesh = wm
            wheel.rotation_degrees.z = 90
            wheel.position = Vector3(x,0.45,z)
            wheel.material_override = _mat(Color(0.025,0.025,0.025),1)
            root.add_child(wheel)

func _build_player():
    var scene = load("res://scripts/player.gd")
    player = CharacterBody3D.new()
    player.set_script(scene)
    player.name = "Player"
    player.position = Vector3(0,1,15)
    add_child(player)

func _build_ui():
    ui = load("res://scripts/ui.gd").new()
    add_child(ui)

func _spawn_wave():
    if not player or player.dead: return
    var count = 1 if not _is_night() else 2
    if rng.randf() < 0.18: count += 1
    for i in range(count):
        var a = rng.randf_range(0,TAU)
        var d = rng.randf_range(24,45)
        var pos = player.position + Vector3(cos(a)*d,0,sin(a)*d)
        var z = load("res://scripts/zombie.gd").new()
        z.position = pos
        var roll = rng.randf()
        if _is_night() and roll < 0.08:
            z.kind = "brute"
        elif roll < 0.25:
            z.kind = "runner"
        elif roll < 0.36:
            z.kind = "crawler"
        else:
            z.kind = "common"
        add_child(z)
        zombies.append(z)

func _mat(c:Color, rough:float) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = c
    m.roughness = rough
    return m
