extends CharacterBody3D

var kind := "common"
var hp := 100.0
var speed := 1.8
var damage := 10.0
var attack_range := 1.6
var attack_cd := 0.0
var state := "wander"
var target
var model: Node3D
var hit_flash := 0.0
var wander_dir := Vector3.ZERO
var wander_time := 0.0

func _ready():
    add_to_group("zombies")
    _configure_kind()
    _build_model()
    target = get_tree().get_first_node_in_group("player")
    if not target:
        target = get_parent().get_node_or_null("Player")

func _configure_kind():
    match kind:
        "runner":
            hp=75; speed=4.2; damage=14; attack_range=1.5
        "brute":
            hp=330; speed=1.25; damage=30; attack_range=2.3
        "crawler":
            hp=55; speed=3.0; damage=8; attack_range=1.3
        _:
            hp=100; speed=1.8; damage=10

func _physics_process(delta):
    if not is_instance_valid(target): return
    attack_cd=max(0,attack_cd-delta)
    hit_flash=max(0,hit_flash-delta)
    var d=global_position.distance_to(target.global_position)
    if d<18:
        state="chase"
    elif d<35 and randf()<0.01:
        state="chase"
    else:
        state="wander"
    if state=="chase":
        _chase(delta)
    else:
        _wander(delta)
    if d<attack_range and attack_cd<=0:
        target.take_damage(damage)
        attack_cd=1.2 if kind!="brute" else 1.8
    if global_position.y < -5: queue_free()

func _chase(delta):
    var desired=(target.global_position-global_position)
    desired.y=0
    if desired.length()>0:
        desired=desired.normalized()
        # slight orbiting makes groups less linear
        var side=Vector3(-desired.z,0,desired.x)
        desired=(desired + side*sin(Time.get_ticks_msec()*0.001+get_instance_id())*0.18).normalized()
        velocity.x=move_toward(velocity.x,desired.x*speed,12*delta)
        velocity.z=move_toward(velocity.z,desired.z*speed,12*delta)
        look_at(global_position+Vector3(velocity.x,0,velocity.z),Vector3.UP)
    _gravity(delta)
    move_and_slide()

func _wander(delta):
    wander_time-=delta
    if wander_time<=0:
        wander_time=randf_range(1,3)
        wander_dir=Vector3(randf_range(-1,1),0,randf_range(-1,1)).normalized()
    velocity.x=move_toward(velocity.x,wander_dir.x*speed*0.35,5*delta)
    velocity.z=move_toward(velocity.z,wander_dir.z*speed*0.35,5*delta)
    _gravity(delta)
    move_and_slide()

func _gravity(delta):
    if not is_on_floor(): velocity.y-=18*delta
    else: velocity.y=0

func take_damage(amount):
    hp-=amount
    hit_flash=0.12
    if hp<=0:
        _die()

func _die():
    var p=GPUParticles3D.new()
    p.amount=25
    p.lifetime=0.35
    p.position.y=1.0
    var pm=ParticleProcessMaterial.new()
    pm.direction=Vector3(0,1,0)
    pm.spread=70
    pm.initial_velocity_min=2
    pm.initial_velocity_max=6
    pm.gravity=Vector3(0,-8,0)
    p.process_material=pm
    var q=QuadMesh.new()
    q.size=Vector2(0.12,0.12)
    p.draw_pass_1=q
    add_child(p)
    p.emitting=true
    queue_free()

func _build_model():
    model=Node3D.new()
    add_child(model)
    var body=MeshInstance3D.new()
    var bm=CapsuleMesh.new()
    bm.radius=0.48 if kind=="brute" else 0.38
    bm.height=1.8 if kind!="crawler" else 0.7
    body.mesh=bm
    body.position.y=0.95 if kind!="crawler" else 0.42
    body.scale=Vector3(1.3,1.25,1.3) if kind=="brute" else Vector3.ONE
    body.material_override=_mat(Color(0.25,0.32,0.24) if kind!="brute" else Color(0.20,0.14,0.12),0.95)
    model.add_child(body)
    var head=MeshInstance3D.new()
    var hm=SphereMesh.new()
    hm.radius=0.32 if kind!="brute" else 0.44
    hm.height=hm.radius*2
    head.mesh=hm
    head.position.y=2.0 if kind!="crawler" else 0.75
    head.material_override=_mat(Color(0.38,0.30,0.25),0.9)
    model.add_child(head)
    if kind=="brute":
        var horn=MeshInstance3D.new()
        var h=BoxMesh.new()
        h.size=Vector3(1.2,0.25,0.25)
        horn.mesh=h
        horn.position.y=2.0
        horn.material_override=_mat(Color(0.12,0.08,0.06),1)
        model.add_child(horn)

func _mat(c:Color,r:float)->StandardMaterial3D:
    var m=StandardMaterial3D.new()
    m.albedo_color=c
    m.roughness=r
    return m
